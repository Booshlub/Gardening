@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Image1</div>

                <div class="panel-body">
                    <img src="img/img1.jpg" width="100%">
                </div>
				<div class="panel-footer">
					<img src="img/comm.png" width="100%">
				</div>
            </div>
			<div class="panel panel-default">
                <div class="panel-heading">Image2</div>

                <div class="panel-body">
                    <img src="img/img2.jpg" width="100%">
                </div>
				<div class="panel-footer">Panel Footer</div>
            </div>
        </div>
    </div>
</div>
@endsection
